from azure.kusto.data import KustoClient, KustoConnectionStringBuilder, DataFormat, ClientRequestProperties
from azure.kusto.data.exceptions import KustoServiceError
from azure.kusto.data.helpers import dataframe_from_result_table
from azure.kusto.ingest import QueuedIngestClient, IngestionProperties, FileDescriptor, BlobDescriptor, ReportLevel, ReportMethod

import pandas as pd

AAD_TENANT_ID = "f01e930a-b52e-42b1-b70f-a8882b5d043b"
KUSTO_URI = "https://utopadx.southeastasia.kusto.windows.net/"
KUSTO_INGEST_URI = "https://ingest-utopadx.southeastasia.kusto.windows.net/"
KUSTO_DATABASE = "utopAnalytics"

KCSB_INGEST = KustoConnectionStringBuilder.with_aad_device_authentication(
    KUSTO_INGEST_URI, AAD_TENANT_ID)

KCSB_DATA = KustoConnectionStringBuilder.with_aad_device_authentication(
    KUSTO_URI, AAD_TENANT_ID)

import pyodbc
import pandas as pd

server = 'tcp:utop-operation-server-pro.database.windows.net'
database = 'utop-operation-db-pro'
username = 'hanhtv13'
password = '1LU5GXLqh9zH'

cnxn = pyodbc.connect('DRIVER={SQL Server};SERVER='+server+';PORT=1433;DATABASE='+database+';UID='+username+';PWD='+ password)

df = pd.read_sql_query("SELECT * FROM [dbo].[UserTransaction]", cnxn)

#----create table------
# KUSTO_CLIENT = KustoClient(KCSB_DATA)
# CREATE_TABLE_COMMAND = ".create table StormEvents (StartTime: string, EndTime: string)"
# RESPONSE = KUSTO_CLIENT.execute_mgmt(KUSTO_DATABASE, CREATE_TABLE_COMMAND)

# QUERY = "Coupon | count"
# KUSTO_CLIENT = KustoClient(KCSB_DATA)
# RESPONSE = KUSTO_CLIENT.execute_query(KUSTO_DATABASE, QUERY)

# print(dataframe_from_result_table(RESPONSE.primary_results[0]))

INGESTION_CLIENT = QueuedIngestClient(KCSB_INGEST)

INGESTION_PROPERTIES = IngestionProperties(database="utopAnalytics", table="sql_dbo_AllocationHistory", data_format=DataFormat.CSV)
            
INGESTION_CLIENT.ingest_from_dataframe(df, INGESTION_PROPERTIES)


